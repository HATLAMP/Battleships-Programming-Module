# Flask game logic
